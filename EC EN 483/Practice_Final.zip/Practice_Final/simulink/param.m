P.m = 0.1;
P.ell = 0.25;
P.b = 0.1;
P.g = 9.8;
P.k1 = 0.02;
P.k2 = 0.01;

P.Ts  = 0.01;
P.tau = .005;
P.tau_max = 3;





